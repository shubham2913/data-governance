import re
import json
import sys
import os
import time
import datetime
import contextlib
#import pytesseract
import tika
from tika import parser
#from PIL import Image
import requests
from requests.auth import HTTPBasicAuth
logFilePath="/root/ocr-app/log.txt"
def getErrorInfo():
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
	errorString = "FileName : " + fname + ", LineNumber : " + str(exc_tb.tb_lineno) + ", ExceptionType : "+ str(exc_type) +", Exception : "+ str(exc_obj)
	return (errorString)

def getCurrentTime() :
	return datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
	
def getFileList(directoryPath):
	with open(logFilePath,"a") as logFileObject:
		try:
			fileList=[]
			fileList1 = os.listdir(directoryPath)
			for file in fileList1 :
				if os.path.isfile(directoryPath+"/"+file) and '.txt' not in file :
					fileList.append(file)
			print("number of files are " + str(len(fileList)))
			return fileList
		except Exception as e:
            		logFileObject.write(" :: ERROR :: " +"Getting List of images from the given directory FAILED : ",getErrorInfo() + '\n\n')

userParameters=[]
			
def getUserMetadata(directoryPath):
	with open(logFilePath,"a") as logFileObject:
		try:
			userMetadataDictionary = {}
			if os.path.exists(directoryPath+"/userMetadata.txt"):
				with open(directoryPath+"/userMetadata.txt","r") as fileObject:
					lines = fileObject.readlines()
					for i in range(0,len(lines)):
						line = lines[i]
						splitWords = line.split('=')
						if(len(splitWords)==2):
							userParameters.append(splitWords[0].strip())
							userMetadataDictionary[splitWords[0].strip()]=splitWords[1].strip()
							print("key is " + splitWords[0].strip() + " and value is " + splitWords[1].strip())
			return userMetadataDictionary
		except Exception as e:
			logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while getting the user specified metadata : ",getErrorInfo() + '\n\n')

def getParameters(directoryPath) :
	with open(logFilePath,"a") as logFileObject:
		try :
			parametersDictionary = {}
			if os.path.exists(directoryPath+"/input/parameters.txt"):
				with open(directoryPath+"/input/parameters.txt","r") as fileObject:
					lines = fileObject.readlines()
					for i in range(0,len(lines)):
						line=lines[i]
						splitWords=line.split("=")
						if(len(splitWords)==2):
							parametersDictionary[splitWords[0].strip()]=splitWords[1].strip()
			else :
				raise Exception("metadata parameters not generated")
			return parametersDictionary
		except Exception as e :
			logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while getting the user specified metadata : ",getErrorInfo() + '\n\
n')


				
def get_total(file) :
	if '.pdf' in file :
		text=get_pdf_data(file)
	else :
		text=get_image_data(file)
	text=text.lower()                                                                                                                                               
	pattern=re.compile("\s*total[^0-9]*\d{1,9}")                                                                                                                    
	iterator=pattern.finditer(text)                                                                                                                                 
	for match in iterator :                                                                                                                                         
		start,end=match.span()                                                                                                                                  
		total=text[start:end]                                                                                                                                   
	pattern=re.compile("\d{1,9}")                                                                                                                                   
	iterator=pattern.finditer(total)                                                                                                                                
	for match in iterator :                                                                                                                                         
		start,end=match.span()                                                                                                                                  
		total=total[start:end]                                                                                                                                  
	return int(total) 			

def get_date(file) :
	if '.pdf' in file :
		text=get_pdf_data(file)
	else :
		text=get_image_data(file)
	text=text.lower()
	#print(text)
	print("hiiii")
	pattern1=re.compile("[0-9]{1,2}-[0-9]{1-2}-[0-9]{2,4}")
	pattern2=re.compile("[0-9]{1,2}/[0-9]{1-2}/[0-9]{2,4}")
	patterns=[pattern1,pattern2]
	pattern=re.compile("order\s+placed\s+at:\s+[^,]+,")
	iterator=pattern.finditer(text)
	date="abc"
	for match in iterator :
		start,end=match.span()
		s1=text[start:end]
		#print(s1)
		date=s1[-11:-1]
		#print(date)
	return date

def get_qualifiedname(file) :
	return file.split("/")[-1]

def get_name(file) :
	return file.split("/")[-1]
	

def getAtlasCommonDictionary(typeName) :
	with open(logFilePath,"a") as logFileObject:
		try :
			dictionary1={}
			dictionary1["jsonClass"]="org.apache.atlas.typesystem.json.InstanceSerialization$_Reference"
			idDictionary={ "jsonClass": "org.apache.atlas.typesystem.json.InstanceSerialization$_Id", "version": 0, "typeName": typeName, "state": "ACTIVE" }
			dictionary1["id"]=idDictionary
			dictionary1["typeName"]=typeName
			dictionary1["traitNames"]=["Metadata_Type"]
			traitDictionary={"jsonClass":"org.apache.atlas.typesystem.json.InstanceSerialization$_Struct","typeName":"Metadata_Type","values":{"type_name":typeName}}
			dictionary1["traits"]={"Metadata_Type":traitDictionary}
			return dictionary1
		except Exception as e:                                                                                                                                  
                        logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')

def generateAtlasEntity(filePath,typeName,metadata) :
	with open(logFilePath,"a") as logFileObject:
		try :
			if os.path.exists(filePath)==False :
				os.mkdir(filePath)
			entityFilePath=filePath+"/"+"entities.json"
			commonDictionary=getAtlasCommonDictionary(typeName)
			print(commonDictionary)
			for i in range(0,len(metadata)) :
				metadata[i].update(commonDictionary)
			with open(entityFilePath,"w") as fileObject :
				fileObject.write(str(metadata))
		except Exception as e:                                                                                                                                  
                        logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')
			
def get_pdf_data(file) :
	with open(logFilePath,"a") as logFileObject:                                                                                                                    
		try :
			tika.initVM()
			parsed=parser.from_file(file)
			text=parsed["content"]
			return text		
		except Exception as e:                                                                                                                                  
                        logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')


def get_image_data(file) :                                                                                                                                
	with open(logFilePath,"a") as logFileObject:                                                                                                                    
		try :                                                                                                                                    
			text=pytesseract.image_to_string(Image.open(file))
			return text                                                                                                                                     
		except Exception as e:                                                                                                                                  
			logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')

listOfFunctions=[get_date,get_total,get_qualifiedname,get_name]

def getMetadata(directoryPath,type) :
	with open(logFilePath,"a") as logFileObject:
		try:
			#tika.initVM()
			if directoryPath[-1]=="/" :
				directoryPath=directoryPath[0:-1]
			fileList=getFileList(directoryPath)
			metadata=[]
			userMetadataDictionary=getUserMetadata(directoryPath)
			parametersDictionary=getParameters(directoryPath)
			#parametersDictionary={"Total":"required"}
			for file in fileList :
				extractedMetadataDictionary={}
				for parameter,multiplicity in parametersDictionary.items() :
					if parameter in userParameters :
						continue
					flag=0
					for function in listOfFunctions :
						if ("get_" + parameter.lower())==function.__name__ :
							parameter_function=function
							flag=1
							break
					if flag==0 and multiplicity=="required":
						raise Exception("function for extraction of required parameter " + parameter + " not defined")
					elif flag==0 and multiplicity=="optional" :
						continue
					value = parameter_function(directoryPath + "/" + file)
					#get_date(directoryPath + "/" + file)
					#print(type(value))
					extractedMetadataDictionary[parameter]=value 
					print("value of " + parameter + " in " + file + " is " + str(value))
				extractedMetadataDictionary.update(userMetadataDictionary)
				extractedMetadataDictionary["name"] = file
				extractedMetadataDictionary["qualifiedName"] = file
				fileMetadata={"values" : extractedMetadataDictionary}
				metadata.append(fileMetadata)
			#print(metadata)
			generateAtlasEntity(directoryPath+"/"+"output",type,metadata)
		except Exception as e:
        		logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')
			

def insert_entities(directoryPath) :
	try :
		url='http://localhost:21000/api/atlas/entities'
		response=requests.post(url,auth=HTTPBasicAuth('admin','admin'),data=directoryPath+"/output/entities.json")
		print(response.json())
	except Exception as e :
		print(e)

def generate_shell(directoryPath,type) :
	try :
		with open(directoryPath+"/output/hdfs.sh","w") as fileObject :
			hdfsDirectory="/" + directoryPath.split("/")[-1] + "_" + type
			fileObject.write("hdfs dfs -mkdir " + hdfsDirectory)
			fileObject.write("\n")
			fileObject.write("hdfs dfs -put " + directoryPath + "/* " + hdfsDirectory)
	except Exception as e:
		print(e)

directoryPath=sys.argv[1]
if directoryPath[-1]=="/" :
	directoryPath=directoryPath[0:-1]
type=sys.argv[2]
getMetadata(directoryPath,type)
#insert_entities(directoryPath)
generate_shell(directoryPath,type)

			
