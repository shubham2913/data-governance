from PIL import Image, ImageEnhance, ImageFilter
import pytesseract
import sys
import os
import pyocr
filename="/root/ocr-app/" + sys.argv[1]
tools = pyocr.get_available_tools()
#print(tools)
tool=tools[0]
txt = tool.image_to_string( Image.open(filename), builder=pyocr.builders.TextBuilder() )
print(txt)
