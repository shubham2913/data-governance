hdfs dfs -mkdir /Swiggy_Orders_FoodBills
hdfs dfs -put /root/ocr-app/Swiggy_Orders/* /Swiggy_Orders_FoodBills