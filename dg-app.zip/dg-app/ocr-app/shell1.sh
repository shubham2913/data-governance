hdfs dfs -mkdir /user/root/ocr-app
hdfs dfs -put /root/ocr-app/* /user/root/ocr-app
