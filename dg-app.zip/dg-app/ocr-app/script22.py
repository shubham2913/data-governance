import os
def get_list_of_images(directoryPath) :
	with
