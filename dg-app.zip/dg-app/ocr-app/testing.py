import sys
if sys.argv[1]==null :
	print("no parameter given")
