hdfs dfs -mkdir /data_FoodBills
hdfs dfs -put /root/ocr-app/data/* /data_FoodBills
