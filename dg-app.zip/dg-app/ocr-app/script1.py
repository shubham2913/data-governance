import cv2
from PIL import Image
import pytesseract
import sys
import PyPDF2
import re
import tika
from tika import parser
#print("library import successful")
filename=sys.argv[1]
tika.initVM()
#parsed=parser.from_file("swiggy-order-33062640522.pdf")
parsed=parser.from_file(filename)
#print(parsed["metadata"])
print(parsed["content"])
if('.pdf' in filename) :
	print(" ")
	#pdf_file = open(filename,'rb')
	#read_pdf = PyPDF2.PdfFileReader(pdf_file)
	#page = read_pdf.getPage(0)
	#page_content = page.extractText()
	#print(page_content)
else :
	img1=cv2.imread(filename)
	gray = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
	cv2.imwrite("temp.jpg",gray)
	img=Image.open("/root/ocr-app/" + filename)
	#img=Image.open("temp.jpg")
	text=pytesseract.image_to_string(img)
	#print(text)
	
