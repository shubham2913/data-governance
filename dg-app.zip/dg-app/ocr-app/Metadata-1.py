import re
import json
import sys
import os
import time
import datetime
import contextlib
import pytesseract
import tika
from tika import parser
from PIL import Image
logFilePath="/root/ocr-app/log.txt"
def getErrorInfo():
	exc_type, exc_obj, exc_tb = sys.exc_info()
	fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
	errorString = "FileName : " + fname + ", LineNumber : " + str(exc_tb.tb_lineno) + ", ExceptionType : "+ str(exc_type) +", Exception : "+ str(exc_obj)
	return (errorString)

def getCurrentTime() :
	return datetime.datetime.fromtimestamp(time.time()).strftime('%Y-%m-%d %H:%M:%S')
	
def getImageList(directoryPath):
	with open(logFilePath,"a") as logFileObject:
		try:
			imageList = os.listdir(directoryPath)
			print("number of files are " + str(len(imageList)))
			return imageList
		except Exception as e:
            		logFileObject.write(" :: ERROR :: " +"Getting List of images from the given directory FAILED : ",getErrorInfo() + '\n\n')
			
def getUserMetadata(filePath):
	with open(logFilePath,"a") as logFileObject:
		try:
			userMetadataDictionary = {}
			with open(filePath,"r") as fileObject:
				lines = fileObject.readlines()
				for i in range(0,len(lines)):
					line = lines[i]
					splitWords = line.split('=')
					if(len(splitWords)==2):
						#stringMatch = "\s+".join(splitWords[0].strip().split())
						userMetadataDictionary[splitWords[0].strip()]=splitWords[1].strip()
						print("key is " + splitWords[0].strip() + " and value is " + splitWords[1].strip())
			return userMetadataDictionary
		except Exception as e:
			logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while getting the user specified metadata : ",getErrorInfo() + '\n\n')

def get_total(text) :                                                                                                                                                   
        text=text.lower()                                                                                                                                               
        pattern=re.compile("\s*total[^0-9]*\d{1,9}")                                                                                                                    
        iterator=pattern.finditer(text)                                                                                                                                 
        for match in iterator :                                                                                                                                         
                start,end=match.span()                                                                                                                                  
                total=text[start:end]                                                                                                                                   
        pattern=re.compile("\d{1,9}")                                                                                                                                   
        iterator=pattern.finditer(total)                                                                                                                                
        for match in iterator :                                                                                                                                         
                start,end=match.span()                                                                                                                                  
                total=total[start:end]                                                                                                                                  
        return total 			

			
def getMetadata(directoryPath,userMetadataPath,listOfFunctions) :
	with open(logFilePath,"a") as logFileObject:
		try:
			tika.initVM()
			directoryPath=sys.argv[1]
			imageList=getImageList(directoryPath)
			extractedMetadata={}
			if userMetadataPath=="not supplied" :
				userMetadataDictionary={}
			else :
				userMetadataDictionary=getUserMetadata(userMetadataPath)
			for image in imageList :
				extractedMetadataDictionary={}
				if ".pdf" in image :
					parsed=parser.from_file(directoryPath + "/" + image)
					text=parsed["content"]
				else :
					text=pytesseract.image_to_string(Image.open(directoryPath + "/" + image))
				for function in listOfFunctions :
					functionName="get_" + function.lower()
					value = get_total(text)
					extractedMetadataDictionary[function]=value 
					print("value of " + function + " in " + image + " is " + value)
				extractedMetadataDictionary.update(userMetadataDictionary)
				extractedMetadata[image]=extractedMetadataDictionary
			print(extractedMetadata)
		except Exception as e:
        		logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while extracting metadata from images : ",getErrorInfo() + '\n\n')
			

def getListOfFunctions(listOfFunctionsPath) :
	with open(logFilePath,"a") as logFileObject:
		try:
			listOfFunctions=[]
			with open(listOfFunctionsPath,"r") as fileObject:
				lines = fileObject.readlines()
				for i in range(0,len(lines)):
					line = lines[i]
					listOfFunctions.append(line.strip())
			return listOfFunctions
		except Exception as e:
        		logFileObject.write(getCurrentTime() + " :: ERROR :: " +"Caught an exception while getting the list : ",getErrorInfo() + '\n\n')


			

directoryPath=sys.argv[1]
print("directory path specified by the user is " + directoryPath)
listOfFunctionsPath=sys.argv[2]
print("list of functions path specified by the user is " + listOfFunctionsPath)
listOfFunctions=getListOfFunctions(listOfFunctionsPath)
if(len(sys.argv)==3) :
	userMetadataPath="not supplied"
	print("user has not specified any metadata")
else :
	userMetadataPath=sys.argv[3]
	print("user has specified metadata")
	
getMetadata(directoryPath,userMetadataPath,listOfFunctions)


			
