curl -i -X GET -H 'Content-Type: application/json' -H 'Accept: application/json' -u admin -p admin 'http://localhost:21000/api/atlas/types/Asset'
