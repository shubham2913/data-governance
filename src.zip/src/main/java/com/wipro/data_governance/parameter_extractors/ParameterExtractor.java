package com.wipro.data_governance.parameter_extractors;

public interface ParameterExtractor {
    public String getValue(String file , String text);
}
